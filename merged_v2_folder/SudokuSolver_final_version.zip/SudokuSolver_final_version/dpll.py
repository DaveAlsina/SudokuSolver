def complemento(letter):
    if len(letter) == 1:
        complement = '-' + letter
        return complement

    elif (len(letter) > 1):
        if (letter[0] == '-'):
            return letter[1]
    else:
        # print(f"error, literal invalido {letra}")
        raise(f"error, literal invalido {letter}")

def hay_unidad(S):
    for x in S:
        if len(x) == 1:
            return x[0]
    return None

def unit_propagate(S, I):
    unidad = hay_unidad(S)

    while ([] not in S) and (unidad != None):
        complement = complemento(unidad)

        #borra las listas que contienen la unidad
        S = [c for c in S if unidad not in c]
        count = 0

        for c in S:                 #sustituye las sublistas de S quitandoles el 'complement'
            if complement in c:
                c = [x for x in c if x != complement]
                S[count] = c

            count += 1

        if '-' in unidad:
            I[complement] = False
        else:
            I[unidad] = True

        unidad = hay_unidad(S)
    return S, I

def DPLL(S,I):
    S, I = unit_propagate(S,I)

    if [] in S:
        return "Insatisfacible", {}

    elif len(S) == 0:
        return "Satisfacible", I

    else:

        #toma el primer elemento(atomo 'l') de 'S'
        l = S[0][0]

        #construye una copia de 'S' en la que no se incluyen las sublistas
        #que contienen al átomo 'l'
        S2copy = [x for x in S if l not in x]

        #sustituye las sublistas de S quitandoles el 'complement
        complement  = complemento(l)
        count = 0
        for c in S2copy:
            if complement in c:
                c = [x for x in c if x != complement]
                S2copy[count] = c
            count += 1
        count = 0

        #hace una copia del diccionario I, y modifica los valores
        #de verdad de esta copia
        I2copy = I

        if len(l)==1:
            I2copy[l] = True
        else:
            I2copy[complement] = False

        S3copy, I3copy = DPLL(S2copy , I2copy)            #parte recursiva del dpll

        if (S3copy == "Satisfacible"):      #caso solución
            return S3copy, I3copy

        #CASO BACK TRACKING

        #construye una copia de 'S' en la que no se incluyen las sublistas
        #que contienen al átomo 'complement'
        S3copy = [x for x in S if complement not in x]

        #sustituye las sublistas de S quitandoles el 'l'
        count = 0
        for c in S3copy:
            if l in c:
                c = [x for x in c if x != l]
                S3copy[count] = c
            count += 1
        count = 0

        #hace una copia del diccionario I, y modifica los valores
        #de verdad de esta copia
        I3copy = I

        if len(l)==1:
            I3copy[l] = 0
        else:
            I3copy[complement] = 1
        return DPLL(S3copy, I3copy)         #continuación del caso recursivo para el BACK TRACKING
