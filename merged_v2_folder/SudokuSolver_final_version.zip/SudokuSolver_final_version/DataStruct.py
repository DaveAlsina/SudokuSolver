from math import sqrt
from dpll import *

class SudokuDataStruct():
	def __init__(self, size ,regla=[]):
		self.size  = size									#tamaño del sudoku del juego
		self.data, self.letters = self.datastruct()			#inicialización de 'self.data' (diccionario de interpretaciones)
															#y 'self.letters' lista con las letras proposicionales para las
															#casillas del sudoku y sus posibles números

		self.regla = regla									#guarda la regla para solucionar el problema cuando se exija

	def datastruct(self):
		nums = [n for n in range(self.size)]				#genera todos los números posibles para el tamaño del juego
		self.No = len(nums)									#atributo nuevo que indica la cantidad de números
		datastrc = {}										#diccionario para las interpretaciones
		letras = []											#lista con los atomos del diccionario

		for n in nums:										#construcción del diccionario inicial
			for i in range(self.size):						#itera en las numeros y en las combinaciones de coordenadas (x,y)
				for j in range(self.size):					#para construirlos átomos del diccionario

					#codifica una coordenada (x,y) en un numero código
					coordCode = self.codifica(i,j,self.size, self.size)

					"""charCoordCode = chr( coordCode + 256 )
					#codifíca en numero código coordenada en una letra"""

					numCode = self.codifica( coordCode, n, self.size**2, len(nums) )
					charNumCode = chr( numCode + 256 )

					#tupla de número y estado en tablero
					#inicializado a falso por defecto
					datastrc[charNumCode] = False
					letras.append(charNumCode)

		return datastrc , letras

	def clearData(self):

		for i in list(self.data.keys()):				#pone todas las letras del diccionario en falso cuando la intefaz lo pida
			self.data[i] = False


	def codifica(self, f, c, Nf, Nc):
		# Funcion que codifica la fila f y columna c

		msg1 = 'Primer argumento incorrecto! Debe ser un numero entre 0 y ' + str(self.size - 1) + "\nSe recibio " + str(f)
		msg2 = 'Segundo argumento incorrecto! Debe ser un numero entre 0 y ' + str(self.size - 1)  + "\nSe recibio " + str(c)
		assert((f >= 0) and (f <= Nf - 1)), msg1

		assert((c >= 0) and (c <= Nc - 1)), msg2

		n = Nc * f + c
		# print(u'Número a codificar:', n)

		return n

	def decodifica(self, n, Nf, Nc): #n es un numero
		# Funcion que codifica un caracter en su respectiva fila f y columna c de la tabla

		msg = 'Codigo incorrecto! Debe estar entre 0 y ' + str(self.size * self.size - 1) + "\nSe recibio " + str(n)
		assert((n >= 0) and (n <= Nf * Nc - 1)), msg

		f = int(n / Nc)
		c = n % Nc

		return f, c

	def decodificaLetra(self,letra):
		a,num = self.decodifica(ord(letra)-256, self.size**2 , self.No)
		x,y = self.decodifica(a , self.size , self.size)

		return ((x,y), num)

	def valueWrite(self , x , y , num = -1):

		print(x,y,num)
		#en caso de ser num==-1 se hace un borrado del numero en la celda
		#por lo que también se debe actualizar el diccionario a 'False' en dicho átomo
		if num == -1 :
			for i in range(self.No):
				coordinatesCode = self.codifica(x, y, self.size, self.size)
				numCode = self.codifica( coordinatesCode, i , self.size**2 , self.No)

				for j in list(self.data.keys()):
					if j == chr(numCode+256):
						self.data[j] = False

		#caso de sobreescritura de una letra proposicional en la interfaz
		#y por lo tanto el cambio se debe ver reflejado en la estructura de datos
		#este mismo caso sirve para añadir un nuevo valor de verdad (cuando la celda
		#no se está sobreescribiendo, sino que ese encuenta vacía)
		else:
			coordinatesCode = self.codifica(x, y, self.size, self.size)
			for numero in range(self.size):
				numCode = self.codifica( coordinatesCode, numero , self.size**2 , self.No)
				for j in list(self.data.keys()):
					if j == chr(numCode+256):
						self.data[j] = False

			numCode = self.codifica( coordinatesCode, num , self.size**2 , self.No)
			for j in list(self.data.keys()):
				if j == chr(numCode+256):
					self.data[j] = True

		#print(self.data)


	def solve(self):
		#función en la que se resuelve el problema planteado en el sudoku

		lst = []					#lista en la que se van a guardar tuplas de la forma ((x,y), num)
									#que son el insumo para que cuando este método sea invocado en la interfaz
									#se pueda graficar en la interfaz de una forma trivial

		regla_dpll = []				#la contiene la regla de la magia :)

		for key, value in self.data.items(): #esta es la regla que prácticamente es invisible
			lst2 = []						 #es la regla de: "utilice las letras proposicionales
											 #que se han escrito ya en el diccionario y la interfaz
			if value == True:				 #para poder hacer la solución respectiva de su problema
				lst2.append(key)			 #y poder solucionar todo más rápido"

			regla_dpll += lst2				#agregue las letras que ya están en true al diccionario de reglas

		regla_dpll += self.regla			#después de haber añadido la regla de solución particular(la de arriba)
											#agregue las demás reglas de solución genéricas
		A = ""
		A , self.data = DPLL(regla_dpll, self.data)		#solucione con dpll
		regla_dpll = []
		#print(A ,self.data)

		print(A)
		#tome las letras que están en verdadero y que también que representan coordenadas y números
		#esto para evitar intentar hacer el display de letras que no tienen significado en la interfaz gráfica
		#recuerde que 'self.letters' es la lista que contiene las letras proposicionales del inicio
		true_letters = [i for i in self.data if i in self.letters]

		for i in true_letters:				#prepara la información para que sea interpretable en la interfaz
			if self.data[i]== True:
				(x,y),num = self.decodificaLetra(i)
				lst.append(((x,y),num))

		#print(lst)
		return lst, A

	def coordenadasColumna(self, col):			#obtiene las coordenadas de las casillas que
		helper = []								#están alineadas con la columna 'col' que se recibe

		for i in range(self.size):
			helper.append((col, i))

		return helper

	def  coordenadasFila(self, fila): 			#obtiene las coordenadas de las casillas que
		helper = []								#están alineadas con la fila 'fila' que se recibe

		for i in range(self.size):
			helper.append((i, fila))

		return helper

	def coordenadasReg(self, col, fila):		#obtiene las coordenadas de las casillas que
												#están alineadas con la region (col, fila) que se recibe
		rcol = int( (col)/sqrt(self.size) )
		rfila = int( (fila)/sqrt(self.size) )
		#print(col, fila)

		coordinates = []

		for i in range(int(sqrt(self.size))):
			for j in range(int(sqrt(self.size))):

				position = ( int(i + sqrt(self.size)*rcol), int(j + sqrt(self.size)*rfila))

				if position == (col, fila):
					continue

				coordinates.append(position)

		return coordinates

	def regionRule(self, n):

		#decodifica la letra proposicional dada y
		#guarda sus valoes codificados en variables de ayuda

		info = self.decodificaLetra(n)
		coordinates = info[0]
		num = info[1]

#		print("coordenadas", coordinates, "numero", num)

		#obtiene las coordenadas que están en la misma región para el átomo recibido
		regCoordinates = self.coordenadasReg(coordinates[0], coordinates[1])

		rule = ""							#regla donde se guardará la regla de la región
		first = True						#variable centinela para la creación correcta de la fórmula

		for i in regCoordinates:			#itera a través de las distintas coordenadas que están en la misma región

			if i == coordinates:			#caso importante en la construcción de la regla para evitar contradiccion formal
				continue					#(evito aplicar la regla al átomo en el que me encuentro)

			#constucción de la letra proposicional
			coordCode = self.codifica(i[0], i[1],self.size, self.size)
			"""charCoordCode = chr( coordCode + 256 )    para poder construir la regla en funcion de las letras proposicionales
			#codifíca en numero código coordenada en una letra"""
			numCode = self.codifica( coordCode, num, self.size**2, self.size)
			charNumCode = chr( numCode + 256 )

			if first:						#montaje de la fórmula (otoria)
				rule += charNumCode
				first = False
			else:
				rule += charNumCode + 'O'


		rule += "-"							#negación de la otoria
		rule += n + ">"						#cereza del pastel (la implicación hacia nuestro átomo 'n')
		return rule


	def columnRule(self, n):
		#decodifica la letra proposicional dada y
		#guarda sus valoes codificados en variables de ayuda

#		print(n)
		info = self.decodificaLetra(n)
		coordinates = info[0]
		num = info[1]

#		print("coordenadas", coordinates, "numero", num)

		#obtiene las columnas que están alineadas con la de la letra proposicional
		col_coordinates = self.coordenadasColumna(coordinates[0])

		rule = ""								#guarda la regla proposiconal
		first = True 							#variable centinela para la primera iteración

		for i in col_coordinates:				#itera a través de las distintas coordenadas que están en la misma columna

			if i == coordinates:				#caso importante en la construcción de la regla para evitar contradiccion formal
				continue						#(evito aplicar la regla al átomo en el que me encuentro)

			#constucción de la letra proposicional
			coordCode = self.codifica(i[0], i[1],self.size, self.size)
			"""charCoordCode = chr( coordCode + 256 )    para poder construir la regla en funcion de las letras proposicionales
			#codifíca en numero código coordenada en una letra"""

			numCode = self.codifica( coordCode, num, self.size**2, self.size)
			charNumCode = chr( numCode + 256 )

			if(first):							#montaje de la fórmula (otoria)
				rule += charNumCode
				first = False
			else:
				rule += charNumCode  + 'O'

		rule += "-"								#negación de la otoria
		rule += n + ">"							#cereza del pastel (la implicación hacia nuestro átomo 'n')
		return rule


	def rowRule(self, n):
		#decodifica la letra proposicional dada y
		#guarda sus valoes codificados en variables de ayuda

#		print(n)
		info = self.decodificaLetra(n)
		coordinates = info[0]
		num = info[1]

		#obtiene las filas que están alineadas con la de la letra proposicional
		row_coordinates = self.coordenadasFila(coordinates[1])


		rule = ""								#regla donde se guardará la regla de la fila
		first = True							#variable centinela para la creación correcta de la fórmula

		for i in row_coordinates:				#itera a través de las distintas coordenadas que están en la misma fila

			if i == coordinates:				#caso importante en la construcción de la regla para evitar contradiccion formal
				continue						#(evito aplicar la regla al átomo en el que me encuentro)

			#constucción de la letra proposicional
			coordCode = self.codifica(i[0], i[1],self.size, self.size)
			"""charCoordCode = chr( coordCode + 256 )
			#codifíca en numero código coordenada en una letra"""

			numCode = self.codifica( coordCode, num, self.size**2, self.size)
			charNumCode = chr( numCode + 256 )

			if(first):							#montaje de la fórmula (otoria)
				rule += charNumCode
				first = False
			else:
				rule += charNumCode  + 'O'


		rule += "-"								#negación de la otoria
		rule += n + ">"							#cereza del pastel (la implicación hacia nuestro átomo 'n')
		return rule

	def cellRule(self):							#regla primordial en este juego, nos indica que por
												#para toda celda en el juego debe haber un número asignado

		coords = []								#lista que almacena las tuplas de coordenadas para todas las casillas del juego
		first = True							#variables centinela para la creación correcta de la fórmula
		second = True


		for coordx in range(self.size):			#rellenado de coords con todas las posiciones (x,y) del sudoku
			for coordy in range(self.size):
				coords.append((coordx,coordy))

		rule = ""								#variable para la regla 'local'
		complete_rule = ""						#variable para almacenar la regla completa


		for i in coords:						#iterado a través de todas las tuplas de coordenadas (x,y)
			for num in range(self.size):		#itera para todos los números

				#crea el átomo
				coordCode = self.codifica(i[0], i[1],self.size, self.size)
				numCode = self.codifica(coordCode, num, self.size**2, self.size)
				charNumCode = chr( numCode + 256 )

				if first:						#monta la pequeña regla (otoria que indica las opciones de números por casilla)
					rule += charNumCode
					first = False
				else:
					rule += charNumCode  + 'O'

			if second:							#monta la regla completa, juntando todas las otorias de opciones con
				complete_rule += rule			#una itoria
				second = False

			else:
				complete_rule += rule + 'Y'

			first = True						#mantiene el cuidado de la variable centinela
			rule = ""							#limpia la regla local para que sea rellenada en otra iteración

		#print(complete_rule)
		return complete_rule

	def rules(self):

		rules = []				#función no usada *deprecated function*
		rule = ""

		for i in self.letters:

			#regla de la fila, de la columna y de la región juntas con unos 'Y'
			rule += self.rowRule(i)	+ self.columnRule(i) + 'Y' + self.regionRule(i) + 'Y'
			rule += i + '='
			rules.append(rule)
			rule = ""

		first = True
		for i in rules:

			if first:
				rule += i
				first = False

			else:
				rule += i + 'Y'

		return rule


# =====================================================================================================0
#                   Funciones para las reglas
# ==============================================================================================00000
class Tree(object):
	def __init__(self, label, left, right):
		self.left = left
		self.right = right
		self.label = label

def Inorder(f):
    # Imprime una formula como cadena dada una formula como arbol
    # Input: tree, que es una formula de logica proposicional
    # Output: string de la formula
	if f.right == None:
		return f.label
	elif f.label == '-':
		return f.label + Inorder(f.right)
	else:
		return "(" + Inorder(f.left) + f.label + Inorder(f.right) + ")"

def String2Tree(A):
    letrasProposicionales=[chr(x) for x in range(256, 1000)]
    Conectivos = ['O','Y','>','=']
    Pila = []
    for c in A:
        if c in letrasProposicionales:
            Pila.append(Tree(c,None,None))
        elif c=='-':
            FormulaAux = Tree(c,None,Pila[-1])
            del Pila[-1]
            Pila.append(FormulaAux)
        elif c in Conectivos:
            FormulaAux = Tree(c,Pila[-1],Pila[-2])
            del Pila[-1]
            del Pila[-1]
            Pila.append(FormulaAux)
        else:
            print(u"Hay un problema: el símbolo " + str(c)+ " no se reconoce")
    return Pila[-1]
