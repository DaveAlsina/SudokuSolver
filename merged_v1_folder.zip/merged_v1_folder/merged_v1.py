import GUI_v2 as gui
import SudokuDataStructure as SData

root = gui.Tk()
begin = gui.StartWindows(root)
root.mainloop()

if(begin.size != -1):

    rootGame = gui.Tk()
    rootGame.title("Sudoku solver {0}x{0}".format(int(gui.sqrt(begin.size))))
    data = SData.SudokuDataStruct(begin.size)
    game = gui.Sudoku(rootGame,data,begin.size)

    rootGame.mainloop()


print(data.atoms)
